=== Plugin Name ===

Contributors: Wang Yan
Plugin Name: 金数据 Jinshuju Shortcode 
Plugin URI: http://jinshuju.net
Tags: jinshuju, form, 金数据, 表单
Author URI: https://jinshuju.net
Author: Wang Yan
Requires at least: 2.6
Tested up to: 3.3.1
Stable tag: 1.0
Version: 1.0

Allows the use of a special short code [jinshuju] for embedding Jinshuju forms.
使用快捷代码[jinshuju]在wordpress中方便的嵌入金数据表单。

== Description ==

Allows the use of a special short code [jinshuju] for embedding Jinshuju forms. It's best to grab the shortcode from the Jinshuju Share Page.
使用快捷代码[jinshuju]在wordpress中方便的嵌入金数据表单, 可以从金数据的分享页面来获得嵌入wordpress的代码。

**Example:** 
`[jinshuju form=WXDJRa height=458]`

== Installation ==

For old school manual installation people: copy the folder "Jinshuju_shortcode" into the /wp-content/plugins/ folder. Then go to the Plugins area of the Admin and activate. Otherwise, search for "Jinshuju Shortcode Plugin" from the admin area of your WordPress site in Plugins > Add New.

== Screenshots ==

1. Usage of shortcode example 代码使用介绍
2. Where to get shortcode 如何获得代码

== Changelog ==

1.0 - Initial release. 首次发布

== Frequently Asked Questions ==

**What is Jinshuju?**

[Jinshuju](https://jinshuju.net) is a web app that helps anybody build amazing online forms. It's great for people who need to collect data, analyze data and share data quickly, but don't want to deal with programming or servers. 

**Why is this useful?**

Shortcodes are clean! You can already copy and paste JavaScript or iframe code to embed a Jinshuju form onto a WordPress page, but you need to make sure to be in the "HTML" tab of the writing area. If a user is in the "Visual" (default) tab, the embed code will not work. Short codes will work either way.